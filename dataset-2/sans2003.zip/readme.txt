Please read the comprehensive document on this font

  http://www.sanskritweb.net/itrans/itmanual2003.pdf

so that you can use this font Sanskrit2003 properly.

Sanskrit2003.ttf is version 1.1 of 18-September-2005

While the font has been enlarged by additional glyphs,
Itranslator 2003, version 2.0.0.38 of September 2004,
remains the current, valid version of this program.

Before you install the new version 1.1 of this font,
please delete the old version 1.0 of Sanskrit2003.ttf,
otherwise the Windows font handler may get confused.
